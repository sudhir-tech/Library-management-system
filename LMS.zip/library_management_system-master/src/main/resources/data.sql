INSERT IGNORE INTO `user` VALUES 
	(1001,'ADMIN-1','admin1@login','$2a$12$4v38BWf5MqjdTPdX9TmVquzmtRPWqiY2nVTGinpnF/DaKg4xE8P86','ROLE_ADMIN','about admin1'),
	(1002,'ADMIN-2','admin2@login','$2a$12$7ZNQpPxLTku5yL/AyviJxe6QsFxHJAQS6rGwXQOnIrSkG6.cimWf6','ROLE_ADMIN','about admin2');