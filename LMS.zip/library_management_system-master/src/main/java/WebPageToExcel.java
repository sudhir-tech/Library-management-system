import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;

public class WebPageToExcel {
	public static void main(String[] args) {
        String url = "http://localhost:8080/librarian/view_books"; // Replace with the actual URL of the web page
        String outputFile = "output.xlsx"; // Output Excel file

        try {
            Document document = Jsoup.connect(url).get();
            Elements dataElements = document.select("your-css-selector-for-data"); // Adjust CSS selector

            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Data");

            int rownum = 0;
            for (var dataElement : dataElements) {
                Row row = sheet.createRow(rownum++);
                Cell cell = row.createCell(0); // Assuming you want to put the data in the first column
                cell.setCellValue(dataElement.text());
            }

            try (FileOutputStream fileOut = new FileOutputStream(outputFile)) {
                workbook.write(fileOut);
                System.out.println("Excel file written successfully.");
            }

            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
