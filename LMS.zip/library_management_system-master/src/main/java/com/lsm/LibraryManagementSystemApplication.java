package com.lsm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.apache.logging.log4j.*;

@SpringBootApplication
public class LibraryManagementSystemApplication {
	
	private static final Logger logger = LogManager.getLogger(LibraryManagementSystemApplication.class);  


	public static void main(String[] args) {
		
		SpringApplication.run(LibraryManagementSystemApplication.class, args);
		
		logger.info("This is an info message.");
        logger.error("This is an error message.");
	
	}

	
	
}
