package com.lsm;

 import static org.junit.Assert.*;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.*;

class TestMainTest {

	@Test
	void test() {
	 TestMain T = new TestMain();
	 assertEquals(4, T.addd(2, 2));
	 
	}

}
